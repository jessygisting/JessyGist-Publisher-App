@echo off
setlocal
set "GRADLE_VERSION=8.9"
set "DIST_DIR=%USERPROFILE%\.gradle\manual-wrapper"
set "GRADLE_HOME=%DIST_DIR%\gradle-%GRADLE_VERSION%"
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  if not exist "%DIST_DIR%" mkdir "%DIST_DIR%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$u='https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip'; $z='%DIST_DIR%\gradle-%GRADLE_VERSION%-bin.zip'; Invoke-WebRequest $u -OutFile $z; Expand-Archive -Force $z '%DIST_DIR%'"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_HOME%\bin\gradle.bat" -p "%~dp0" %*
