# JessyGist Publisher Android App

This Android wrapper opens the existing JessyGist Admin dashboard inside an app window.

## Features
- Opens `https://jessygisting.github.io/JessyGist/Admin.html`.
- Supports Firebase email/password sign-in through the existing website.
- Supports selecting an image from the phone for the website's Cloudinary upload form.
- Uses the existing Firestore database and security rules.

## Security
The app does not store Firebase passwords or Cloudinary secrets. Authentication and article permissions remain controlled by Firebase and the website's existing security configuration.

## Build
- JDK 17
- Android SDK 35
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.20
- Gradle 8.9

On GitHub Actions, the workflow installs Gradle 8.9 and runs `gradle assembleDebug`. It does not depend on a checked-in Gradle Wrapper JAR.

For local command-line builds, `gradlew` / `gradlew.bat` bootstrap Gradle 8.9 from the official Gradle distribution service. Android Studio can also open the project and sync it using the configured Gradle distribution.

## Important
The app requires an internet connection. The dashboard is hosted at the JessyGist GitHub Pages URL.
